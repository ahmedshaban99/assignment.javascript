// create an array
let myNums = [1, 2, 3, 4];
// create a variable for the sum and initialize it
let sum = 0;
// iterate over each item in the array
for (let x = 0; x < myNums.length; x++ ) {
  sum += myNums[x];
}
console.log(sum) ;